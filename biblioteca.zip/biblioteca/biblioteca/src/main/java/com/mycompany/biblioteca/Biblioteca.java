/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.biblioteca;

/**
 *
 * @author Pichau
 */
public class Biblioteca {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
