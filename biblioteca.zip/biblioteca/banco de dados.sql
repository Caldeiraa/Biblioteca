create database biblioteca;

use biblioteca;

create table cadastro_livros (
	id int	primary key auto_increment,
    nome varchar(100),
    autor varchar(100),
    editora varchar(100),
    paginas int,
    sinopse varchar(200),
    clasificacao varchar(20)
);
 
select * from cadastro_livros;

create table cadastro_cliente (
	id int primary key auto_increment,
    nome varchar(100),
    cpf varchar(11) unique not null, 
    contato varchar(11),
    email varchar(100) unique not null, 
    login varchar(20), 
    senha varchar(20) 
);

select * from cadastro_cliente;

create table emprestimo (
	id int primary key auto_increment,
    cliente_id int not null,
    livro_id int not null, 
    emprestimo date, 
    devolucao date,
    CONSTRAINT fk_cliente FOREIGN KEY (cliente_id) REFERENCES cadastro_cliente(id),
    CONSTRAINT fk_livro FOREIGN KEY (livro_id) REFERENCES cadastro_livros(id)
);
alter table emprestimo add column devolvido boolean default false;
select * from emprestimo;

CREATE VIEW ViewEmprestimos AS
SELECT emprestimo.id, emprestimo.emprestimo, emprestimo.devolucao, cadastro_cliente.nome AS nome_cliente, cadastro_livros.nome AS nome_livro
FROM emprestimo
INNER JOIN cadastro_cliente ON emprestimo.cliente_id = cadastro_cliente.id
INNER JOIN cadastro_livros ON emprestimo.livro_id = cadastro_livros.id;


SELECT * FROM ViewEmprestimos;